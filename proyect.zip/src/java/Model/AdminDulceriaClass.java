/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
/**
 *
 * @author Alberto
 */
public class AdminDulceriaClass {
    
    private String TableName = "PA2_CINEMA_DULCERIA";       
    

    public AdminDulceriaClass() {
    }
    
    
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para insertar un registro en la dulceria
    public int SQLInsertProducto(        
        String Nombre,
        String Descripcion,
        String Precio,
        String Imagen
    ){
        int Result = 0;
        try{
            Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
            
            String sql = "INSERT INTO "+TableName+" (NOMBRE,DESCRIPCION,PRECIO,IMAGEN) "
                    + "VALUES (?,?,?,?)";
            
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            
            sentencia.setString(1, Nombre);
            sentencia.setString(2, Descripcion);
            sentencia.setString(3, Precio);
            sentencia.setString(4, Imagen);
            
            int a = sentencia.executeUpdate();
            
            if(a == 1){
                Result = 1;
            }else{
                Result = 0;
            }
            
        }catch(Exception e){
            e.printStackTrace();
            Result = 0;
        }
        
        return Result;
    }    
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para editar un producto
    public int SQLEditProducto(
        String CodigoProducto,
        String Nombre,
        String Descripcion,
        String Precio,
        String Imagen        
    ){
        int Result = 0;
        
        try{
            Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
            
            String sql = "UPDATE "+TableName+" "
                    + "SET Nombre = ?,"
                    + "DESCRIPCION = ?,"
                    + "PRECIO = ?,"
                    + "IMAGEN = ?,"                    
                    + "WHERE CODIGO_PRODUCTO = ?";
            
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            
            sentencia.setString(1, Nombre);
            sentencia.setString(2, Descripcion);
            sentencia.setString(3, Precio);
            sentencia.setString(4, Imagen);
            sentencia.setString(5, CodigoProducto);
            
            
            int a = sentencia.executeUpdate();
            
            if(a == 1){
                Result = 1;
            }else{
                Result = 0;
            }
            
        }catch(Exception e){
            e.printStackTrace();
            Result = 0;
        }
        
        return Result;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para Eliminar una pelicula
    public int SQLDeleteProducto(int CodigoProducto){
        int Result = 0;
        try{
            Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
            
            String sql = "DELETE FROM "+TableName+" WHERE CODIGO_PRODUCTO = ?";
            
            PreparedStatement sentencia = conexion.prepareStatement(sql);           
                      
            sentencia.setInt(1, CodigoProducto);            
            
            int a = sentencia.executeUpdate();
            
            if(a == 1){
                Result = 1;
            }else{
                Result = 0;
            }
            
        }catch(Exception e){
            e.printStackTrace();
            Result = 0;
        }
        
        
        return Result;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para listar todos los productos
    public ResultSet getProductos(){
        ResultSet rs = null;
        try{
                Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
                
                Statement sentencia = conexion.createStatement();               
                
                String sql = "SELECT * FROM APP."+TableName+" order by CODIGO_PRODUCTO desc";
                
                rs = sentencia.executeQuery(sql);                
        }
        catch(Exception exc){
            exc.printStackTrace();
            
        }
        return rs;
        
    }        
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para encontrar un producto 
    public ResultSet FindProducto(int CodigoProducto){
        ResultSet rs = null;
        try{
                Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
                
                Statement sentencia = conexion.createStatement();               
                
                String sql = "SELECT * FROM "+TableName+" WHERE CODIGO_PRODUCTO = "+CodigoProducto+" ";
                
                rs = sentencia.executeQuery(sql);
        }
        catch(Exception exc){
            exc.printStackTrace();
            rs = null;
        }
        
        return rs;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    
    
}
