/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import com.sun.mail.smtp.*;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.InternetAddress;

public class Mailer {
    
    private String AdminMail = "alberto.soriano864@gmail.com";
    private String AdminPass = "ebe04497-276e-4020-aa8b-fb74cd87a905";
    private String SMTPServer = "smtp.elasticemail.com";
    private String SMTPPort = "2525";
    private String ClientMail = "";

    public String getAdminMail() {
        return AdminMail;
    }

    public void setAdminMail(String AdminMail) {
        this.AdminMail = AdminMail;
    }

    public String getAdminPass() {
        return AdminPass;
    }

    public void setAdminPass(String AdminPass) {
        this.AdminPass = AdminPass;
    }

    public String getSMTPServer() {
        return SMTPServer;
    }

    public void setSMTPServer(String SMTPServer) {
        this.SMTPServer = SMTPServer;
    }

    public String getSMTPPort() {
        return SMTPPort;
    }

    public void setSMTPPort(String SMTPPort) {
        this.SMTPPort = SMTPPort;
    }

    public String getClientMail() {
        return ClientMail;
    }

    public void setClientMail(String ClientMail) {
        this.ClientMail = ClientMail;
    }
    
    
    public String SendMail(String ClientMail ,String Pelicula,String Sala,String Fecha,String Asiento,String Formato){
        String Resultado = "";
        String Code = Long.toHexString(Double.doubleToLongBits(Math.random())).toUpperCase();
        Properties props = new Properties();
        props.put("mail.smtp.host", SMTPServer);
        props.put("mail.smtp.socketFactory.port", SMTPPort);
        props.put("mail.smtp.socketFactory.class",
                "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", SMTPPort);

        Session session = Session.getInstance(props,new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(AdminMail,AdminPass);
            }
        });

        try {

            SMTPMessage message = new SMTPMessage(session);
            message.setFrom(new InternetAddress(AdminMail));
            message.setRecipients(Message.RecipientType.TO,
                                     InternetAddress.parse( ClientMail ));

            message.setSubject("Comprobante de Compra");
            message.setText("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n" +
                            "<html>\n" +
                            "\n" +
                            "<head>\n" +
                            "    <meta charset=\"UTF-8\">\n" +
                            "    <meta content=\"width=device-width, initial-scale=1\" name=\"viewport\">\n" +
                            "    <meta name=\"x-apple-disable-message-reformatting\">\n" +
                            "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n" +
                            "    <meta content=\"telephone=no\" name=\"format-detection\">\n" +
                            "    <title></title>\n" +
                            "    <!--[if (mso 16)]>\n" +
                            "    <style type=\"text/css\">\n" +
                            "    a {text-decoration: none;}\n" +
                            "    </style>\n" +
                            "    <![endif]-->\n" +
                            "    <!--[if gte mso 9]><style>sup { font-size: 100% !important; }</style><![endif]-->\n" +
                            "    <!--[if !mso]><!-- -->\n" +
                            "    <link href=\"https://fonts.googleapis.com/css?family=Open Sans:400,400i,700,700i\" rel=\"stylesheet\">\n" +
                            "    <!--<![endif]-->\n" +
                            "</head>\n" +
                            "\n" +
                            "<body>\n" +
                            "    <div class=\"es-wrapper-color\">\n" +
                            "        <!--[if gte mso 9]>\n" +
                            "			<v:background xmlns:v=\"urn:schemas-microsoft-com:vml\" fill=\"t\">\n" +
                            "				<v:fill type=\"tile\" color=\"#eeeeee\"></v:fill>\n" +
                            "			</v:background>\n" +
                            "		<![endif]-->\n" +
                            "        <table class=\"es-wrapper\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n" +
                            "            <tbody>\n" +
                            "                <tr>\n" +
                            "                    <td class=\"esd-email-paddings\" valign=\"top\">\n" +
                            "                        <table class=\"es-content esd-header-popover\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">\n" +
                            "                            <tbody>\n" +
                            "                                <tr>\n" +
                            "                                </tr>\n" +
                            "                                <tr>\n" +
                            "                                    <td class=\"esd-stripe\" esd-custom-block-id=\"7954\" align=\"center\">\n" +
                            "                                        <table class=\"es-content-body\" style=\"background-color: transparent;\" width=\"600\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">\n" +
                            "                                            <tbody>\n" +
                            "                                                <tr>\n" +
                            "                                                    <td class=\"esd-structure es-p15t es-p15b es-p10r es-p10l\" align=\"left\">\n" +
                            "                                                        <!--[if mso]><table width=\"580\" cellpadding=\"0\" cellspacing=\"0\"><tr><td width=\"282\" valign=\"top\"><![endif]-->\n" +
                            "                                                        <table class=\"es-left\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\">\n" +
                            "                                                            <tbody>\n" +
                            "                                                                <tr>\n" +
                            "                                                                    <td class=\"esd-container-frame\" width=\"282\" align=\"left\">\n" +
                            "                                                                        <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n" +
                            "                                                                            <tbody>\n" +
                            "                                                                                <tr>\n" +
                            "                                                                                    <td class=\"es-infoblock esd-block-text es-m-txt-c\" align=\"left\">\n" +
                            "                                                                                        <p style=\"font-family: arial, helvetica\\ neue, helvetica, sans-serif;\">Notificacion de compra</p>\n" +
                            "                                                                                    </td>\n" +
                            "                                                                                </tr>\n" +
                            "                                                                            </tbody>\n" +
                            "                                                                        </table>\n" +
                            "                                                                    </td>\n" +
                            "                                                                </tr>\n" +
                            "                                                            </tbody>\n" +
                            "                                                        </table>\n" +
                            "                                                        <!--[if mso]></td><td width=\"20\"></td><td width=\"278\" valign=\"top\"><![endif]-->\n" +
                            "                                                        <table class=\"es-right\" cellspacing=\"0\" cellpadding=\"0\" align=\"right\">\n" +
                            "                                                            <tbody>\n" +
                            "                                                                <tr>\n" +
                            "                                                                    <td class=\"esd-container-frame\" width=\"278\" align=\"left\">\n" +
                            "                                                                        <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n" +
                            "                                                                            <tbody>\n" +
                            "                                                                                <tr>\n" +
                            "                                                                                    <td class=\"es-infoblock esd-block-text es-m-txt-c\" align=\"right\">\n" +
                            "                                                                                        <p><a href=\"http://#\" target=\"_blank\" style=\"font-family: 'arial', 'helvetica neue', 'helvetica', 'sans-serif';\">Ver en navegador</a><br></p>\n" +
                            "                                                                                    </td>\n" +
                            "                                                                                </tr>\n" +
                            "                                                                            </tbody>\n" +
                            "                                                                        </table>\n" +
                            "                                                                    </td>\n" +
                            "                                                                </tr>\n" +
                            "                                                            </tbody>\n" +
                            "                                                        </table>\n" +
                            "                                                        <!--[if mso]></td></tr></table><![endif]-->\n" +
                            "                                                    </td>\n" +
                            "                                                </tr>\n" +
                            "                                            </tbody>\n" +
                            "                                        </table>\n" +
                            "                                    </td>\n" +
                            "                                </tr>\n" +
                            "                            </tbody>\n" +
                            "                        </table>\n" +
                            "                        <table class=\"es-content\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">\n" +
                            "                            <tbody>\n" +
                            "                                <tr>\n" +
                            "                                </tr>\n" +
                            "                                <tr>\n" +
                            "                                    <td class=\"esd-stripe\" esd-custom-block-id=\"7681\" align=\"center\">\n" +
                            "                                        <table class=\"es-header-body\" style=\"background-color: rgb(4, 71, 103);\" width=\"600\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#044767\" align=\"center\">\n" +
                            "                                            <tbody>\n" +
                            "                                                <tr>\n" +
                            "                                                    <td class=\"esd-structure es-p35t es-p35b es-p35r es-p35l\" align=\"left\">\n" +
                            "                                                        <!--[if mso]><table width=\"530\" cellpadding=\"0\" cellspacing=\"0\"><tr><td width=\"340\" valign=\"top\"><![endif]-->\n" +
                            "                                                        <table class=\"es-left\" cellspacing=\"0\" cellpadding=\"0\" align=\"left\">\n" +
                            "                                                            <tbody>\n" +
                            "                                                                <tr>\n" +
                            "                                                                    <td class=\"es-m-p0r es-m-p20b esd-container-frame\" width=\"340\" valign=\"top\" align=\"center\">\n" +
                            "                                                                        <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n" +
                            "                                                                            <tbody>\n" +
                            "                                                                                <tr>\n" +
                            "                                                                                    <td class=\"esd-block-text es-m-txt-c\" align=\"left\">\n" +
                            "                                                                                        <h1 style=\"padding:5px 25px 5px 25px;color: #ffffff; line-height: 100%;\"> <b>Cine</b>Pro<br></h1>\n" +
                            "                                                                                    </td>\n" +
                            "                                                                                </tr>\n" +
                            "                                                                            </tbody>\n" +
                            "                                                                        </table>\n" +
                            "                                                                    </td>\n" +
                            "                                                                </tr>\n" +
                            "                                                            </tbody>\n" +
                            "                                                        </table>\n" +
                            "                                                        <!--[if mso]></td><td width=\"20\"></td><td width=\"170\" valign=\"top\"><![endif]-->\n" +
                            "                                                        <table cellspacing=\"0\" cellpadding=\"0\" align=\"right\">\n" +
                            "                                                            <tbody>\n" +
                            "                                                                <tr class=\"es-hidden\">\n" +
                            "                                                                    <td class=\"es-m-p20b esd-container-frame\" esd-custom-block-id=\"7704\" width=\"170\" align=\"left\">\n" +
                            "                                                                        <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n" +
                            "                                                                            <tbody>\n" +
                            "                                                                                <tr>\n" +
                            "                                                                                    <td class=\"esd-block-spacer es-p5b\" align=\"center\">\n" +
                            "                                                                                        <table width=\"100%\" height=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">\n" +
                            "                                                                                            <tbody>\n" +
                            "                                                                                                <tr>\n" +
                            "                                                                                                    <td style=\"border-bottom: 1px solid rgb(4, 71, 103); background: rgba(0, 0, 0, 0) none repeat scroll 0% 0%; height: 1px; width: 100%; margin: 0px;\"></td>\n" +
                            "                                                                                                </tr>\n" +
                            "                                                                                            </tbody>\n" +
                            "                                                                                        </table>\n" +
                            "                                                                                    </td>\n" +
                            "                                                                                </tr>\n" +
                            "                                                                                <tr>\n" +
                            "                                                                                    <td>\n" +
                            "                                                                                        <table cellspacing=\"0\" cellpadding=\"0\" align=\"right\">\n" +
                            "                                                                                            <tbody>\n" +
                            "                                                                                                <tr>\n" +
                            "                                                                                                    <td align=\"left\">\n" +
                            "                                                                                                        <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n" +
                            "                                                                                                            <tbody>\n" +
                            "                                                                                                                <tr>\n" +
                            "                                                                                                                    <td class=\"esd-block-text\" align=\"right\">\n" +
                            "                                                                                                                        <p><a target=\"_blank\" style=\"font-size: 18px; line-height: 120%;\" href=\"#\">Pagina</a></p>\n" +
                            "                                                                                                                    </td>\n" +
                            "                                                                                                                </tr>\n" +
                            "                                                                                                            </tbody>\n" +
                            "                                                                                                        </table>\n" +
                            "                                                                                                    </td>\n" +
                            "                                                                                                    <td class=\"esd-block-image es-p10l\" valign=\"top\" align=\"left\">\n" +
                            "                                                                                                        <a href target=\"_\"><img src=\"https://tlr.stripocdn.email/content/guids/CABINET_75694a6fc3c4633b3ee8e3c750851c02/images/77981522050090360.png\" alt style=\"display: block;\" width=\"27\"></a> </td>\n" +
                            "                                                                                                </tr>\n" +
                            "                                                                                            </tbody>\n" +
                            "                                                                                        </table>\n" +
                            "                                                                                    </td>\n" +
                            "                                                                                </tr>\n" +
                            "                                                                            </tbody>\n" +
                            "                                                                        </table>\n" +
                            "                                                                    </td>\n" +
                            "                                                                </tr>\n" +
                            "                                                            </tbody>\n" +
                            "                                                        </table>\n" +
                            "                                                        <!--[if mso]></td></tr></table><![endif]-->\n" +
                            "                                                    </td>\n" +
                            "                                                </tr>\n" +
                            "                                            </tbody>\n" +
                            "                                        </table>\n" +
                            "                                    </td>\n" +
                            "                                </tr>\n" +
                            "                            </tbody>\n" +
                            "                        </table>\n" +
                            "                        <table class=\"es-content\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">\n" +
                            "                            <tbody>\n" +
                            "                                <tr>\n" +
                            "                                    <td class=\"esd-stripe\" align=\"center\">\n" +
                            "                                        <table class=\"es-content-body\" width=\"600\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#ffffff\" align=\"center\">\n" +
                            "                                            <tbody>\n" +
                            "                                                <tr>\n" +
                            "                                                    <td class=\"esd-structure es-p40t es-p35b es-p35r es-p35l\" esd-custom-block-id=\"7685\" style=\"background-color: rgb(247, 247, 247);\" bgcolor=\"#f7f7f7\" align=\"left\">\n" +
                            "                                                        <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n" +
                            "                                                            <tbody>\n" +
                            "                                                                <tr>\n" +
                            "                                                                    <td class=\"esd-container-frame\" width=\"530\" valign=\"top\" align=\"center\">\n" +
                            "                                                                        <table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n" +
                            "                                                                            <tbody>\n" +
                            "                                                                                <tr>\n" +
                            "                                                                                    <td class=\"esd-block-image es-p20t es-p25b es-p35r es-p35l\" align=\"center\">\n" +
                            "                                                                                        <a  href=\"https://viewstripo.email/\"> <img style=\"height: 40%; width: auto;\" src=\"https://image.freepik.com/free-vector/red-cinema-ribbon-with-movie-elements_23-2147544053.jpg\" alt=\"ship\" style=\"display: block;\" title=\"ship\" width=\"150\"> </a> </td>\n" +
                            "                                                                                </tr>\n" +
                            "                                                                                <tr>\n" +
                            "                                                                                    <td class=\"esd-block-text es-p15b\" align=\"center\">\n" +
                            "                                                                                        <h2 style=\"color: #333333; font-family: 'open sans', 'helvetica neue', helvetica, arial, sans-serif;\">Codigo de Entrada:</h2>\n" +
                            "                                                                                    </td>\n" +
                            "                                                                                </tr>\n" +
                            "                                                                                <tr>\n" +
                            "                                                                                    <td class=\"esd-block-text es-m-txt-l es-p20t\" align=\"left\">\n" +
                            "                                                                                        <center>\n" +
                            "                                                                                            <h1 style=\"font-family: sans-serif;\">"+Code+"<br></h1>\n" +
                            "                                                                                        </center>\n" +
                            "                                                                                    </td>\n" +
                            "                                                                                </tr>\n" +
                            "                                                                                <tr>\n" +
                            "                                                                                    <td class=\"esd-block-text es-p15t es-p10b\" align=\"left\">\n" +
                            "                                                                                        <center>\n" +
                            "                                                                                        <p style=\"font-size: 16px; color: #777777;\">Este codigo corresponde a su boleto por favor presentelo en la entrada para acceder a su funcion!</p>\n" +
                            "                                                                                        </center>\n" +
                            "                                                                                    </td>\n" +
                            "                                                                                </tr>\n" +
                            "                                                                                <tr>\n" +
                            "                                                                                    <td class=\"esd-block-button es-p25t es-p20b es-p10r es-p10l\" align=\"center\">\n" +
                            "                                                                                        <h3>Detalle de la orden</h3>\n" +
                            "                                                                                        \n" +
                            "                                                                                            <p><b>Pelicula:</b> "+Pelicula+" </p>\n" +
                            "                                                                                            <p><b>Fecha Funcion: "+Fecha+"</b> </p>\n" +
                            "                                                                                            <p><b>Sala: </b> "+Sala+" </p>\n" +
                            "                                                                                            <p><b>Asiento: </b> "+Asiento+" </p>\n" +
                            "                                                                                            <p><b>Formato: </b> "+Formato+" </p>\n" +
                            "                                                                                          \n" +
                            "                                                                                    </td>\n" +
                            "                                                                                </tr>\n" +
                            "                                                                            </tbody>\n" +
                            "                                                                        </table>\n" +
                            "                                                                    </td>\n" +
                            "                                                                </tr>\n" +
                            "                                                            </tbody>\n" +
                            "                                                        </table>\n" +
                            "                                                    </td>\n" +
                            "                                                </tr>\n" +
                            "                                                \n" +
                            "            </tbody>\n" +
                            "        </table>\n" +
                            "    </div>\n" +
                            "</body>\n" +
                            "\n" +
                            "</html>","UTF-8","HTML");
            //message.setContent("");
            message.setNotifyOptions(SMTPMessage.NOTIFY_SUCCESS);
            int returnOption = message.getReturnOption();
            System.out.println(returnOption);        
            Transport.send(message);
            System.out.println("Correo Enviado: "+ClientMail);
            Resultado ="Enviado";

        }
         catch (MessagingException e) {
            throw new RuntimeException(e);               
         }
        
        
        return  Resultado;
    }
    
}


/*package Model;

import com.sun.mail.smtp.SMTPMessage;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Mailer {
public static void main(String[] args) {
    Properties props = new Properties();
    props.put("mail.smtp.host", "smtp.elasticemail.com");
    props.put("mail.smtp.socketFactory.port", "2525");
    props.put("mail.smtp.socketFactory.class",
            "javax.net.ssl.SSLSocketFactory");
    props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.port", "2525");

    Session session = Session.getDefaultInstance(props,new javax.mail.Authenticator() {
        @Override
        protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("alberto.soriano864@gmail.com","ebe04497-276e-4020-aa8b-fb74cd87a905");
        }
    });

    try {

        SMTPMessage message = new SMTPMessage(session);
        message.setFrom(new InternetAddress("alberto.soriano864@gmail.com"));
        message.setRecipients(Message.RecipientType.TO,
                                 InternetAddress.parse( "alberto.soriano@ops.com.hn" ));

        message.setSubject("Testing Subject");
        message.setText("This is Test mail");
        //message.setContent("This Is my First Mail Through Java");
        message.setNotifyOptions(SMTPMessage.NOTIFY_SUCCESS);
        int returnOption = message.getReturnOption();
        System.out.println(returnOption);        
        Transport.send(message);
        System.out.println("sent");

    }
     catch (MessagingException e) {
        throw new RuntimeException(e);         
     }
  }
}*/