package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Alberto
 */
public class AdminPeliculasClass {
    
    private String TableName = "PA2_CINEMA_PELICULA";
    private String CodigoPelicula = "CODIGO_PELICULA";
    private String NombrePelicula = "NOMBRE_PELICULA";
    private String Autor = "AUTOR";
    private String Genero = "GENERO";
    private String Sala = "SALA";
    private String Formato = "FORMATO";
    private String Horarios = "HORARIOS";
    private String FechaRegistro = "FECHA_REGISTRO";
    private String UrlImagen = "IMAGEN";
    private String Descripcion = "DESCRIPCION";
    
    public void AdminPeliculas(){
        
    }
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metdo para agregar una pelicula a la base de datos
    public int SQLInsertPelicula(
        String NombrePelicula,
        String Descripcion,
        String Autor,
        String Genero,
        String Sala,
        String Formato,
        String Horarios,
        String FechaRegistro,
        String UrlImagen
    ){
        int Result = 0;
        try{
            Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
            
            String sql = "INSERT INTO "+TableName+" (NOMBRE_PELICULA,DESCRIPCION,AUTOR,GENERO,SALA,FORMATO,HORARIOS,FECHA_REGISTRO,IMAGEN) "
                    + "VALUES (?,?,?,?,?,?,?,?,?)";
            
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            
            sentencia.setString(1, NombrePelicula);
            sentencia.setString(2, Descripcion);
            sentencia.setString(3, Autor);
            sentencia.setString(4, Genero);
            sentencia.setString(5, Sala);
            sentencia.setString(6, Formato);
            sentencia.setString(7, Horarios);
            sentencia.setString(8, FechaRegistro);
            sentencia.setString(9, UrlImagen);            
            
            int a = sentencia.executeUpdate();
            
            if(a == 1){
                Result = 1;
            }else{
                Result = 0;
            }
            
        }catch(Exception e){
            e.printStackTrace();
            Result = 0;
        }
        
        return Result;
    }    
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para editar una pelicula en la base de datos
    public int SQLEditPelicula(
        String CodigoPelicula,
        String NombrePelicula,
        String Descripcion,
        String Autor,
        String Genero,
        String Sala,
        String Formato,
        String Horarios,
        String FechaRegistro,
        String UrlImagen
    ){
        int Result = 0;
        
        try{
            Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
            
            String sql = "UPDATE "+TableName+" "
                    + "SET NOMBRE_PELICULA = ?,"
                    + "DESCRIPCION = ?,"
                    + "AUTOR = ?,"
                    + "GENERO = ?,"
                    + "SALA = ?,"
                    + "FORMATO = ?,"
                    + "HORARIOS = ?,"
                    + "FECHA_REGISTRO = ?,"
                    + "IMAGEN = ?"
                    + "WHERE CODIGO_PELICULA = ?";
            
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            
            sentencia.setString(1, NombrePelicula);
            sentencia.setString(2, Descripcion);
            sentencia.setString(3, Autor);
            sentencia.setString(4, Genero);
            sentencia.setString(5, Sala);
            sentencia.setString(6, Formato);
            sentencia.setString(7, Horarios);
            sentencia.setString(8, FechaRegistro);
            sentencia.setString(9, UrlImagen);            
            sentencia.setString(10, CodigoPelicula);            
            
            int a = sentencia.executeUpdate();
            
            if(a == 1){
                Result = 1;
            }else{
                Result = 0;
            }
            
        }catch(Exception e){
            e.printStackTrace();
            Result = 0;
        }
        
        return Result;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para eliminar una pelicula
    public int SQLDeletePelicula(int CodigoPelicula){
        int Result = 0;
        try{
            Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
            
            String sql = "DELETE FROM "+TableName+" WHERE CODIGO_PELICULA = ?";
            
            PreparedStatement sentencia = conexion.prepareStatement(sql);           
                      
            sentencia.setInt(1, CodigoPelicula);            
            
            int a = sentencia.executeUpdate();
            
            if(a == 1){
                Result = 1;
            }else{
                Result = 0;
            }
            
        }catch(Exception e){
            e.printStackTrace();
            Result = 0;
        }
        
        
        return Result;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para listar toda la informacion de las peliculas
    public ResultSet getPeliculas(){
        ResultSet rs = null;
        try{
                Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
                
                Statement sentencia = conexion.createStatement();               
                
                String sql = "SELECT * FROM APP."+TableName+" order by CODIGO_PELICULA desc";
                
                rs = sentencia.executeQuery(sql);                
        }
        catch(Exception exc){
            exc.printStackTrace();
            
        }
        return rs;
        
    }    
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para encontrar un apelicula    
    public ResultSet FindPelicula(int CodigoPelicula){
        ResultSet rs = null;
        try{
                Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
                
                Statement sentencia = conexion.createStatement();               
                
                String sql = "SELECT * FROM APP.PA2_CINEMA_PELICULA WHERE CODIGO_PELICULA = "+CodigoPelicula+" ";
                
                rs = sentencia.executeQuery(sql);
        }
        catch(Exception exc){
            exc.printStackTrace();
            rs = null;
        }
        
        return rs;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para obtener la ultima pelicula ingresada
    public ResultSet LastPelicual(){
        ResultSet rs = null;
        try{
                Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
                
                Statement sentencia = conexion.createStatement();               
                
                String sql = "SELECT * FROM APP.PA2_CINEMA_PELICULA WHERE CODIGO_PELICULA = (SELECT MAX(CODIGO_PELICULA) FROM PA2_CINEMA_PELICULA)";
                
                rs = sentencia.executeQuery(sql);
        }
        catch(Exception exc){
            exc.printStackTrace();
            rs = null;
        }
        
        return rs;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para obtener las ultimas tres peliculas creadas
    public ResultSet UltimasTresPeliculas(){
        ResultSet rs = null;
        try{
                Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
                
                Statement sentencia = conexion.createStatement();               
                
                String sql = "SELECT * FROM APP.PA2_CINEMA_PELICULA ORDER BY CODIGO_PELICULA DESC FETCH FIRST 3 ROWS ONLY";
                
                rs = sentencia.executeQuery(sql);
        }
        catch(Exception exc){
            exc.printStackTrace();
            rs = null;
        }
        
        return rs;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para insertar una compra
    public int SQLInsertCompra(String Pelicula,String Asientos,String FechaVenta,String Sala,String Formato){
        int Result = 0;
        try{
            Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
            
            String sql = "INSERT INTO PA2_CINEMA_COMPRAS(PELICULA,FECHA_COMPRA,SALA,ASIENTOS,FORMATO) VALUES(?,?,?,?,?)";
            
            PreparedStatement sentencia = conexion.prepareStatement(sql);           
                      
            sentencia.setString(1,Pelicula);            
            sentencia.setString(2,FechaVenta);            
            sentencia.setString(3,Sala);            
            sentencia.setString(4,Asientos);            
            sentencia.setString(5,Formato);            
            
            int a = sentencia.executeUpdate();
            
            if(a == 1){
                Result = 1;
            }else{
                Result = 0;
            }
            
        }catch(Exception e){
            e.printStackTrace();
            Result = 0;
        }
        
        
        return Result;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para insertar un registro en la dulceria
    public int SQLInsertProducto(        
        String Nombre,
        String Descripcion,
        String Precio,
        String Imagen
    ){
        int Result = 0;
        try{
            Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
            
            String sql = "INSERT INTO PA2_CINEMA_DULCERIA (NOMBRE,DESCRIPCION,PRECIO,IMAGEN) "
                    + "VALUES (?,?,?,?)";
            
            PreparedStatement sentencia = conexion.prepareStatement(sql);
            
            sentencia.setString(1, Nombre);
            sentencia.setString(2, Descripcion);
            sentencia.setString(3, Precio);
            sentencia.setString(4, Imagen);
            
            int a = sentencia.executeUpdate();
            
            if(a == 1){
                Result = 1;
            }else{
                Result = 0;
            }
            
        }catch(Exception e){
            e.printStackTrace();
            Result = 0;
        }
        
        return Result;
    }    
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para contar ventas por pelicula
    public ResultSet getVentasPeliculas()
    {
        ResultSet rs = null;
        try{
                Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
                
                Statement sentencia = conexion.createStatement();               
                
                String sql = "SELECT PELICULA,COUNT(PELICULA) AS \"VENTAS\" FROM APP.PA2_CINEMA_COMPRAS GROUP BY PELICULA ORDER BY VENTAS DESC";
                
                rs = sentencia.executeQuery(sql);
        }
        catch(Exception exc){
            exc.printStackTrace();
            rs = null;
        }
        
        return rs;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
//------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para contar ventas por pelicula
    public ResultSet getVentasFechas()
    {
        ResultSet rs = null;
        try{
                Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
                
                Statement sentencia = conexion.createStatement();               
                
                String sql = "SELECT FECHA_COMPRA,COUNT(PELICULA) AS \"VENTAS\" FROM APP.PA2_CINEMA_COMPRAS GROUP BY FECHA_COMPRA ORDER BY FECHA_COMPRA ASC FETCH FIRST 7 ROWS ONLY";
                
                rs = sentencia.executeQuery(sql);
        }
        catch(Exception exc){
            exc.printStackTrace();
            rs = null;
        }
        
        return rs;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    
    //------------------------------------------------------------------------------------------------------------------------------------//
    //Metodo para obtener 
    public ResultSet getVentasHistorico()
    {
        ResultSet rs = null;
        try{
                Connection conexion = DriverManager.getConnection("jdbc:derby://localhost:1527/sample;create=true;user=app;password=app");
                
                Statement sentencia = conexion.createStatement();               
                
                String sql = "SELECT * FROM PA2_CINEMA_COMPRAS";
                
                rs = sentencia.executeQuery(sql);
        }
        catch(Exception exc){
            exc.printStackTrace();
            rs = null;
        }
        
        return rs;
    }
    //------------------------------------------------------------------------------------------------------------------------------------//
    
    
    
    
}
