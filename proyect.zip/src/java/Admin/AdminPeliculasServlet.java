package Admin;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Model.AdminPeliculasClass;
import Model.Mailer;
import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.Part;

/**
 *
 * @author Alberto
 */
@WebServlet(name = "AdminPeliculasServlet", urlPatterns = {"/AdminPeliculasServlet"})
@MultipartConfig
public class AdminPeliculasServlet extends HttpServlet {
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            AdminPeliculasClass Model = new AdminPeliculasClass();
            ResultSet ListaPeliculas = Model.getPeliculas();
            out.println("<div class=\" mt-4\" style='width:95%; margin-left:auto; margin-right:auto; font-family:sans-serif;'>\n" +
"    \n" +
"    <div class=\"card\">\n" +
"        <div class=\"card-header bg-primary white-text\">Lista de peliculas</div>\n" +
"        <div class=\"card-body\">\n" +
"            <!-- Tabla de peliculas -->\n" +
"            <table class=\"table table-hover table-bordered table-responsive w-100 d-block d-md-table table-sm small text-center\" style='widht:100%;' >\n" +
"                <thead class=\"bg-default white-text\">\n" +
"                    <tr>\n" +
"                        <th>#</th>                        \n" +
"                        <th>Nombre</th>                        \n" +
"                        <th>Autor</th>\n" +
"                        <th>Genero</th>\n" +
"                        <th>Sala</th>\n" +
"                        <th>Formatos</th>\n" +
"                        <th>Fecha Registro</th>\n" +
"                        <th>Opciones</th>                        \n" +
"                    </tr>\n" +
"                </thead>\n" +
"                <tbody>\n" +
"                    \n");
                    int i = 1;
                        while(ListaPeliculas.next()){
                            out.println("<tr>");
                            out.println("<td>"+i+"</td>");
                            out.println("<td>"+ListaPeliculas.getString("NOMBRE_PELICULA")+"</td>");
                            out.println("<td>"+ListaPeliculas.getString("AUTOR")+"</td>");                                                       
                            out.println("<td>"+ListaPeliculas.getString("GENERO")+"</td>");                                                       
                            out.println("<td>"+ListaPeliculas.getString("SALA")+"</td>");                                                       
                            out.println("<td>"+ListaPeliculas.getString("FORMATO")+"</td>");                                                       
                            out.println("<td>"+ListaPeliculas.getString("FECHA_REGISTRO")+"</td>");                                                       
                            out.println("<td>"
                                    + "<button id='btnEdit-"+ListaPeliculas.getString("CODIGO_PELICULA")+"' class='btn btn-primary btn-sm'><span class='fas fa-edit'></span></button>"
                                    + "<script type='text/javascript'>"
                                            + "$('#btnEdit-"+ListaPeliculas.getString("CODIGO_PELICULA")+"').click(function(){"
                                                    + "$('#contenido').load('EditPelicula.jsp?CodigoPelicula="+ListaPeliculas.getString("CODIGO_PELICULA")+"');"
                                                    + "});"
                                            + "</script>"
                                            + "</td>");                                           
                            out.println("<tr>");                           
                            i++;
                        }
                        
out.println("</tbody>\n" +
"            </table>\n" +
"            <!-- Tabla de peliculas -->\n" +
"        </div>\n"
        + "<div class=\"card-footer\">\n" +
"            <button type=\"button\" class=\"btn btn-sm btn-primary float-right\" data-toggle=\"modal\" data-target=\"#AgregarPeliculaModal\">\n" +
"                Agregar Pelicula\n" +
"            </button>            \n" +
"        </div>" +
"    </div>\n" +
"    \n" +
"</div>");


//Seccion del modal para agregar una pelicula
out.println("<!-- Modal -->\n" +
"<form id=\"FormAddPelicula\" enctype = \"multipart/form-data\">\n" +
"    <div class=\"modal fade\" id=\"AgregarPeliculaModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"AgregarPeliculaModal\"\n" +
"      aria-hidden=\"true\">\n" +
"      <div class=\"modal-dialog modal-lg\" role=\"document\">\n" +
"        <div class=\"modal-content\">\n" +
"          <div class=\"modal-header\">\n" +
"            <h5 class=\"modal-title\" id=\"exampleModalLabel\">Agregar Pelicula</h5>\n" +
"            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">\n" +
"              <span aria-hidden=\"true\">&times;</span>\n" +
"            </button>\n" +
"          </div>\n" +
"          <div class=\"modal-body\">\n" +
"              <input type=\"hidden\" name=\"form\" value=\"AddPelicula\">\n" +
"              <input type=\"hidden\" value=\"../recursos/Peliculas\" name=\"destination\">\n" +
"              <label>Nombre de la Pelicula</label>\n" +
"              <input type=\"text\" name=\"NombrePelicula\" id=\"NombrePelicula\" class=\"form-control form-control-sm\" required=\"\">\n" +
"              \n" +
"              <label>Nombre del Autor</label>\n" +
"              <input type=\"text\" name=\"Autor\" id=\"Autor\" class=\"form-control form-control-sm\" required=\"\">\n" +
"              \n" +
"              <label>Genero</label>\n" +
"              <select name=\"Genero\" id=\"Genero\" class=\"browser-default custom-select select2\" required=\"\">\n" +
"                  <option></option>\n" +
"                  <option value=\"Drama\">Drama</option>\n" +
"                  <option value=\"Comedia\">Comedia</option>\n" +
"                  <option value=\"Accion\">Accion</option>\n" +
"                  <option value=\"Suspenso\">Suspenso</option>\n" +
"                  <option value=\"Terror\">Terror</option>\n" +
"                  <option value=\"Animada\">Animada</option>\n" +
"                  <option value=\"Infantiles\">Infantiles</option>\n" +
"                  <option value=\"Documental\">Documental</option>\n" +
"                  <option value=\"Biografica\">Biografica</option>\n" +
"                  <option value=\"Otro\">Otro</option>\n" +
"              </select>\n" +
"              \n" +
"              <label>Salas</label>\n" +
"              <select name=\"Salas\" id=\"Salas\" class=\"browser-default custom-select select2\" required=\"\">\n" +
"                  <option></option>\n" +
"                  <option value=\"1\">1</option>\n" +
"                  <option value=\"2\">2</option>\n" +
"                  <option value=\"3\">3</option>\n" +
"                  <option value=\"4\">4</option>                  \n" +
"                  <option value=\"5\">5</option>                  \n" +
"              </select>\n" +
"              \n" +
"              <label>Formatos</label>\n" +
"              <select name=\"Formato\" id=\"Formato\" class=\"browser-default custom-select select2\" required=\"\">\n" +
"                  <option></option>\n" +
"                  <option value=\"2D\">2D</option>                  \n" +
"                  <option value=\"3D\">3D</option>                  \n" +
"                  <option value=\"2D-XD\">2D-XD</option>                  \n" +
"              </select>\n" +
"              \n" +
"              <label>Horarios</label>\n" +
"              <select required=\"\" style=\"width: 100%\" name=\"Horarios[]\" id=\"Horarios\" class=\"browser-default custom-select select2 multiple\"  multiple=\"multiple\">\n" +
"                  <option disabled=\"\"><option>\n" +
"                  <option value=\"13:00\">13:00</option>\n" +
"                  <option value=\"14:00\">14:00</option>\n" +
"                  <option value=\"15:00\">15:00</option>\n" +
"                  <option value=\"16:00\">16:00</option>\n" +
"                  <option value=\"17:00\">17:00</option>\n" +
"                  <option value=\"18:00\">18:00</option>\n" +
"                  <option value=\"19:00\">19:00</option>\n" +
"                  <option value=\"20:00\">20:00</option>\n" +
"                  <option value=\"21:00\">21:00</option>\n" +
"                  <option value=\"22:00\">22:00</option>\n" +
"                  <option value=\"23:00\">23:00</option>\n" +
"              </select>\n" +
"              \n" +
"              <label>Descripcion</label>\n" +
"              <textarea name=\"Descripcion\" class=\"form-control form-control-sm\" id=\"Descripcion\" ></textarea>\n" +
"              \n" +
"              <label>Url de la imagen</label>\n" +
"              <textarea name=\"UrlImagen\" class=\"form-control form-control-sm\" id=\"UrlImagen\" ></textarea>\n" +
"              <input type=\"hidden\" name=\"ListaHorarios\" id=\"ListaHorarios\">\n" +
"              \n" +
"              <input type=\"hidden\" name=\"FechaRegistro\" id=\"FechaRegistro\">\n" +
"              \n" +
"              \n" +
"              \n" +
"          </div>\n" +
"          <div class=\"modal-footer\">\n" +
"            <button type=\"button\" class=\"btn btn-sm btn-warning\" data-dismiss=\"modal\">Cancelar</button>\n" +
"            <button type=\"submit\" class=\"btn btn-sm btn-success\">Agregar Pelicula</button>\n"
        + "<br><div id=\"ResultadoPelicula\"></div>\n" +
"          </div>\n" +
"        </div>\n" +
"      </div>\n" +
"    </div>\n" +
"</form>\n" +
"\n" +
"<div id=\"Resultado\"></div>\n" +
"\n" +
"<script type=\"text/javascript\">\n" +
"    $(\".select2\").select2();\n" +
"    $(\".select2\").css(\"width\",\"100%\");\n" +
"</script>\n" +
"\n" +
"<script type=\"text/javascript\">\n" +
"        $(\"#Horarios\").change(function(){\n" +
"            var ListaHorarios = $(\"#Horarios\").val()\n" +
"           $(\"#ListaHorarios\").val(ListaHorarios); \n" +
"        });\n" +
"</script>\n" +
"\n" +
"<script type=\"text/javascript\">\n" +
"    var hoy = new Date();\n" +
"    var dia = hoy.getDay();\n" +
"    var mes = hoy.getMonth();\n" +
"    var anio = hoy.getFullYear();\n" +
"    var hora = hoy.getHours();\n" +
"    var minuto = hoy.getMinutes();\n" +
"    $(\"#FechaRegistro\").val(anio+'/'+mes+'/'+dia+' '+hora+':'+minuto);\n" +
"</script>\n" +
"\n" +
"<script type=\"text/javascript\">\n" +
"    $(\"#FormAddPelicula\").on(\"submit\",function(e){\n" +
"        e.preventDefault();\n" +
"        $.ajax({\n" +
"                url:'../AdminPeliculasServlet',\n" +
"                method:'POST',\n" +
"                data: new FormData(this),\n" +
"                contentType:false,\n" +
"                cache:false,\n" +
"                processData:false,\n" +
"                success: function(data){\n" +
"                        $(\"#Resultado\").html(data);\n" +
"                }\n" +
"\n" +
"        });\n" +
"    });\n" +
"</script>\n" +
"<!-- Modal -->\n" +
"\n" +
"\n" +
"");
        } catch (SQLException ex) {
            Logger.getLogger(AdminPeliculasServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        
        
        PrintWriter writer = response.getWriter();
        
        //---->Variable que contiene el codigo HTML para imprimir en el navegador
        //---->Este Codigo variara segun los puntos de control del servlet y del manejo de los datos
        String HTMLResponse = "<script type='text/javascript'>"
                + "console.log('%c Fallo en el manejo de formulario!\n No se encuentra la variable de formulario! ', 'padding:15px;font-family:sans-serif;font-size:150%;background: #222; color: #bada55');"
                + "</script>";
        
       //Form es una variable de control para manejar las peticiones de tipo POST       
       String form = request.getParameter("form");
       
       //Instancia de objeto que maneja las transacciones entre la base de datos y el cliente
       AdminPeliculasClass Model = new AdminPeliculasClass();
       
       switch(form){
           //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
           //Control para agregar pelicula
           case "AddPelicula":
               String NombrePelicula = request.getParameter("NombrePelicula");
               String Descripcion = request.getParameter("Descripcion");
               String Autor = request.getParameter("Autor");
               String Genero = request.getParameter("Genero");
               String Sala = request.getParameter("Salas");
               String Formato = request.getParameter("Formato");
               String Horarios = request.getParameter("ListaHorarios");
               String UrlImagen = request.getParameter("UrlImagen");
               String FechaRegistro = request.getParameter("FechaRegistro");               
               
               
               int Result = Model.SQLInsertPelicula(NombrePelicula, Descripcion, Autor, Genero, Sala, Formato, Horarios, FechaRegistro, UrlImagen);
               
               if(Result == 1){
                   //Respuesta del modelo donde la informacion de guardo correctamente en la base de datos
                   System.out.println("OK Registro agregado con exito!");
                   
                    //---->Respuesta al navegador para cerrar el modal de agregar pelicula y recargar el DIV "contenido para refrescar la pagina"
                   HTMLResponse = "<script type=\"text/javascript\">\n"
                           + "$(\".modal\").modal(\"show\",false);\n" 
                           +"$('body').removeClass('modal-open');\n" 
                           +"$('.modal-backdrop').remove();\n"
                           +"$('#contenido').load('../AdminPeliculasServlet');\n"
                           + "</script>";
               }else{
                   
                   //---->Respuesta del modelo donde hay un error al insertar en la base de datos mostramos al usuario que no se guardaron los datos
                   System.out.println("Error");
                   HTMLResponse = "<script type='text/javascript'>"
                           + "console.log('%c No se pudo guardar el registro en la base de datos! ', 'padding:15px;font-family:sans-serif;font-size:150%;background: #222; color: #bada55');\n"
                           + "$('#ResultadoPelicula').html('<div class=\"alert alert-warning\">No se pudo guardar el registro!</div> ');\n"
                           + "setInterval(function(){\n"
                           + "$('#ResultadoPelicula').html('');\n"
                           + "},3000)\n"
                           + "</script>\n";
               }
               
           break;
           //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
           
           //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
           //Control para editar una pelicula
           case "EditPelicula":
               String NombrePeliculaEdit = request.getParameter("NombrePelicula");
               String DescripcionEdit = request.getParameter("Descripcion");
               String AutorEdit = request.getParameter("Autor");
               String GeneroEdit = request.getParameter("Genero");
               String SalaEdit = request.getParameter("Salas");
               String FormatoEdit = request.getParameter("Formato");
               String HorariosEdit = request.getParameter("ListaHorarios");
               String UrlImagenEdit = request.getParameter("UrlImagen");
               String FechaRegistroEdit = request.getParameter("FechaRegistro");
               String CodigoPeliculaEdit = request.getParameter("CodigoPelicula");
               
               int ResultEdit = Model.SQLEditPelicula(CodigoPeliculaEdit,NombrePeliculaEdit,DescripcionEdit,AutorEdit,GeneroEdit,SalaEdit,FormatoEdit,HorariosEdit,FechaRegistroEdit,UrlImagenEdit);
               
               if(ResultEdit == 1){
                   //Respuesta del modelo donde la informacion de guardo correctamente en la base de datos
                   System.out.println("OK Editado con exito!");
                   
                    //---->Respuesta al navegador para cerrar el modal de agregar pelicula y recargar el DIV "contenido para refrescar la pagina"
                   HTMLResponse = "<script type=\"text/javascript\">\n"                           
                           +"alert('Cambios Guardados');"
                           + "window.reload();"
                           + "</script>";
               }else{
                   //---->Respuesta del modelo donde hay un error al insertar en la base de datos mostramos al usuario que no se guardaron los datos
                   System.out.println("Error");
                   HTMLResponse = "<script type='text/javascript'>"
                           + "console.log('%c No se pudo guardar el registro en la base de datos! ', 'padding:15px;font-family:sans-serif;font-size:150%;background: #222; color: #bada55');\n"
                           + "$('#ResultadoPelicula').html('<div class=\"alert alert-warning\">No se pudo guardar el registro!</div> ');\n"
                           + "setInterval(function(){\n"
                           + "$('#ResultadoPelicula').html('');\n"
                           + "},3000)\n"
                           + "</script>\n";
               }
               
           break;
           //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
           
           //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
           //Control para eliminar un registro de pelicula
           case "DeletePelicula":
               String CodigoPeliculaDelete = request.getParameter("CodigoPeliculaDelete");
               
               int CodigoPeliculaInt = Integer.parseInt(CodigoPeliculaDelete);
               
               int ResultDelete = Model.SQLDeletePelicula(CodigoPeliculaInt);
               
               if(ResultDelete == 1){
                   
                   //---->Respuesta al navegador para cerrar el modal de agregar pelicula y recargar el DIV "contenido para refrescar la pagina"
                   HTMLResponse = "<script type=\"text/javascript\">\n"
                           + "$(\".modal\").modal(\"show\",false);\n" 
                           +"$('body').removeClass('modal-open');\n" 
                           +"$('.modal-backdrop').remove();\n"
                           +"$('#contenido').load('../AdminPeliculasServlet');\n"
                           + "</script>";
                   
               }else{
                   //---->Respuesta del modelo donde hay un error al eliminar en la base de datos mostramos al usuario que no se guardaron los datos
                   System.out.println("Error");
                   HTMLResponse = "<script type='text/javascript'>"
                           + "console.log('%c No se pudo eliminar el registro en la base de datos! ', 'padding:15px;font-family:sans-serif;font-size:150%;background: #222; color: #bada55');\n"
                           + "$('#ResultadoPelicula').html('<div class=\"alert alert-warning\">No se pudo guardar el registro!</div> ');\n"
                           + "setInterval(function(){\n"
                           + "$('#ResultadoPelicula').html('');\n"
                           + "},3000)\n"
                           + "</script>\n";
               }
               
           break;
           //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
           
           //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
           //Control para generar las tres peliculas mas recientes
           case "UltimasTresPeliculas":
               //------>Devuelve un div con la plantilla de peliculas para las ultimas tres pelicuals creadas
               ResultSet DataPeliculas = Model.UltimasTresPeliculas();
               
                {
                    try {

                            HTMLResponse = "";
                            while(DataPeliculas.next()){
                                HTMLResponse = HTMLResponse + "<div class=\"col-md-4\">\n" +
                                                            "          <div class=\"card z-depth-1\">\n" +
                                                            "              <div class=\"card-img\">\n" +
                                                            "                  <img class=\"img-fluid mt-2 mb-2\" style=\"height: 400px;width: auto;\"  src='"+DataPeliculas.getString("IMAGEN")+"'/>\n" +
                                                            "              </div>\n" +
                                                            "              <div class=\"card-footer text-left\">\n" +
                                                            "                  <h5 class=\"text-primary\">"+DataPeliculas.getString("NOMBRE_PELICULA")+"</h5>\n" +
                                                            "                  <hr>\n" +
                                                            "                  <p><span class=\"fas fa-film\"></span> Genero: "+DataPeliculas.getString("GENERO")+"</p>\n" +
                                                            "                  <p><span class=\"fas fa-clock\"></span> Horarios: "+DataPeliculas.getString("HORARIOS")+"</p>\n" +
                                                            "                  <div class=\"text-center\">\n" +
                                                            "                      <a href=\"ComprarTicket.jsp?CodigoPelicula="+DataPeliculas.getInt("CODIGO_PELICULA")+"\" class=\"btn btn-outline-primary waves-effect\"><span class=\"fas fa-ticket-alt\"></span> Compar Entrada</a>\n" +
                                                            "                  </div>\n" +
                                                            "              </div>\n" +
                                                            "          </div>\n" +
                                                            "      </div>";
                            }

                    } catch (SQLException ex) {
                        Logger.getLogger(AdminPeliculasServlet.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("Error En la consulta de datos");
                    }
                }
           break;
           //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
           
           //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
           //Control de formulario para agregar compra
           case "ComprarTicket":
               String PeliculaCompra = request.getParameter("NombrePelicula");
               String AsientosCompra = request.getParameter("Asientos");
               String FechaVentaCompra = request.getParameter("FechaVenta");
               String SalaCompra = request.getParameter("sala");
               String FormatoCompra = request.getParameter("Formato");
               
               String CorreoCliente = request.getParameter("CorreoCliente");
               
               int ResultadoCompra = Model.SQLInsertCompra(PeliculaCompra,AsientosCompra,FechaVentaCompra, SalaCompra, FormatoCompra);
               
               if(ResultadoCompra == 1){
                   HTMLResponse = ""
                           + "<br><hr><div class='alert alert-success'>Compra Realizada con exito<br>se envio un correo de confirmacion de la compra a: "+CorreoCliente+"</div><br>"
                           + "<script type='text/javascript'>"
                           + "console.log('Compra realizada con exito!');"
                           + "$(\"#loader\").css(\"display\",\"none\");"                           
                           + "setInterval(function(){"
                           + "window.location.href='Taquilla.jsp';"
                           + "},30000);"
                           + "</script>"
                           + "";
                           
                   
                   Mailer mail = new Mailer();
                   
                   String SendMail = mail.SendMail(CorreoCliente,PeliculaCompra,SalaCompra,FechaVentaCompra,AsientosCompra,FormatoCompra);
                   
                   if(SendMail == "Enviado"){
                       HTMLResponse = HTMLResponse + ""
                               + "<script type='text/javascript'>"
                               + "console.log('%c Correo enviado con exito a la direccion "+CorreoCliente+"', 'padding:15px;font-family:sans-serif;font-size:150%;background: #222; color: #bada55');"
                               + "</script>";
                   }else{
                       HTMLResponse = HTMLResponse + ""
                               + "<script type='text/javascript'>"
                               + "+ \"console.log('%c No se pudo enviar el correo a la direccion "+CorreoCliente+"', 'padding:15px;font-family:sans-serif;font-size:150%;background: #222; color: #bada55');\""
                               + "</script>";
                   }
                   
               }
               
               
               
           break;
           //-----------------------------------------------------------------------------------------------------------------------------------------------------------------//
           
           
           //-------------------------------------------------------------------------------------------------------------------------------------------//
            //Control para agregar producto
            case "AgregarProducto":
                String NombreAdd = request.getParameter("Nombre");
                String DescripcionAdd = request.getParameter("Descripcion");
                String PrecioAdd = request.getParameter("Precio");
                String ImagenAdd = request.getParameter("Imagen");
                
                int ResultInsert = Model.SQLInsertProducto(NombreAdd, DescripcionAdd, PrecioAdd, ImagenAdd);
                
                if(ResultInsert == 1){
                    HTMLResponse = "<script type='text/javascript'>\n"
                            + "alert('Producto Agregado con exito');\n"
                            + "$(\".modal\").modal(\"show\",false);\n"
                            +"$('body').removeClass('modal-open');\n"
                            +"$('.modal-backdrop').remove();\n" 
                            +"$('.modal').modal('hide');\n" 
                            +"$('#contenido').load('AdminDulceria.jsp');\n"
                            + "</script>";
                }else{
                    HTMLResponse = "<script type='text/javascript'>"
                            + "alert('Error: No se puede agregar el producto')"
                            + "</script>";
                }            
            break;
            //-------------------------------------------------------------------------------------------------------------------------------------------//
            
            //-------------------------------------------------------------------------------------------------------------------------------------------//
            //Control para obtener productos
            case "getProductos":
                 //------>Devuelve un div con la plantilla de peliculas para las ultimas tres pelicuals creadas
               ResultSet ProductosLista = Model.UltimasTresPeliculas();
               
                {
                    try {

                            HTMLResponse = "";
                            while(ProductosLista.next()){
                                HTMLResponse = HTMLResponse + "<div class=\"col-md-4\">\n" +
                                                            "          <div class=\"card z-depth-1\">\n" +
                                                            "              <div class=\"card-img\">\n" +
                                                            "                  <img class=\"img-fluid mt-2 mb-2\" style=\"height: 400px;width: auto;\"  src='"+ProductosLista.getString("IMAGEN")+"'/>\n" +
                                                            "              </div>\n" +
                                                            "              <div class=\"card-footer text-left\">\n" +
                                                            "                  <h5 class=\"text-primary\">"+ProductosLista.getString("NOMBRE_PELICULA")+"</h5>\n" +
                                                            "                  <hr>\n" +
                                                            "                  <p><span class=\"fas fa-film\"></span> Genero: "+ProductosLista.getString("GENERO")+"</p>\n" +
                                                            "                  <p><span class=\"fas fa-clock\"></span> Horarios: "+ProductosLista.getString("HORARIOS")+"</p>\n" +
                                                            "                  <div class=\"text-center\">\n" +
                                                            "                      <a href=\"ComprarTicket.jsp?CodigoPelicula="+ProductosLista.getInt("CODIGO_PELICULA")+"\" class=\"btn btn-outline-primary waves-effect\"><span class=\"fas fa-ticket-alt\"></span> Compar Entrada</a>\n" +
                                                            "                  </div>\n" +
                                                            "              </div>\n" +
                                                            "          </div>\n" +
                                                            "      </div>";
                            }

                    } catch (SQLException ex) {
                        Logger.getLogger(AdminPeliculasServlet.class.getName()).log(Level.SEVERE, null, ex);
                        System.out.println("Error En la consulta de datos");
                    }
                }
            break;
            //-------------------------------------------------------------------------------------------------------------------------------------------//
           
           //En caso de que no se capture la variable form o no exista el control
           default:
               HTMLResponse = "<script type='text/javascript'>"
                + "console.log('%c Fallo en el manejo de formulario! No se encuentra la variable de formulario! ', 'padding:15px;font-family:sans-serif;font-size:150%;background: #222; color: #bada55');"
                       + "alert('No se encontro el formulario!');"
                + "</script>";
           break;
       }
       
       //--->Imprimimos el codigo HTML en el navegador
       writer.println(HTMLResponse);
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
