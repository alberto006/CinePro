/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Admin;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Model.AdminDulceriaClass;
import Model.Mailer;
import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.Part;

/**
 *
 * @author Alberto
 */
@WebServlet(name = "AdminDulceriaServlet", urlPatterns = {"/AdminDulceriaServlet"})
public class AdminDulceriaServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AdminDulceriaServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AdminDulceriaServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        
        PrintWriter writer = response.getWriter();
        //---->Variable que contiene el codigo HTML para imprimir en el navegador
        //---->Este Codigo variara segun los puntos de control del servlet y del manejo de los datos
        String HTMLResponse = "<script type='text/javascript'>"
                + "console.log('%c Fallo en el manejo de formulario!\n No se encuentra la variable de formulario! ', 'padding:15px;font-family:sans-serif;font-size:150%;background: #222; color: #bada55');"
                + "</script>";
        
        //Controles de formularios para resolver peticiones de tipo post
        String form = request.getParameter("form");
        
        System.out.println("Peticion: "+ form);
        
        AdminDulceriaClass Model = new AdminDulceriaClass();
        
        switch(form){
            //-------------------------------------------------------------------------------------------------------------------------------------------//
            //Control para agregar producto
            case "AgregarProducto":
                String NombreAdd = request.getParameter("Nombre");
                String DescripcionAdd = request.getParameter("Descripcion");
                String PrecioAdd = request.getParameter("Precio");
                String ImagenAdd = request.getParameter("Imagen");
                
                int ResultInsert = Model.SQLInsertProducto(NombreAdd, DescripcionAdd, PrecioAdd, ImagenAdd);
                
                if(ResultInsert == 1){
                    HTMLResponse = "<script type='text/javascript'>"
                            + "alert('Producto Agregado con exito');"
                            + "+ \"$(\\\".modal\\\").modal(\\\"show\\\",false);\\n\" \n" +
"                           +\"$('body').removeClass('modal-open');\\n\" \n" +
"                           +\"$('.modal-backdrop').remove();\\n\"\n" +
"                           +\"$('#contenido').load('../AdminDulceria.jps');\\n\""
                            + "</script>";
                }else{
                    HTMLResponse = "<script type='text/javascript'>"
                            + "alert('Error: No se puede agregar el producto')"
                            + "</script>";
                }            
            break;
            //-------------------------------------------------------------------------------------------------------------------------------------------//
            
            
            //-------------------------------------------------------------------------------------------------------------------------------------------//
            //Metodo para editar un producto
            
            case "EditarProducto":
                String CodigoProductoEdit = request.getParameter("CodigoProducto");
                String NombreEdit = request.getParameter("Nombre");
                String DescripcionEdit = request.getParameter("Descripcion");
                String PrecioEdit = request.getParameter("Precio");
                String ImagenEdit = request.getParameter("Imagen");
                
                int ResultEdit = Model.SQLEditProducto(CodigoProductoEdit, NombreEdit, DescripcionEdit, PrecioEdit, ImagenEdit);
                
                if(ResultEdit == 1){
                    HTMLResponse = "<script type='text/javascript'>"
                            + "alert('Producto Editado con exito!');"
                            +"$('#contenido').load('../AdminDulceriaEdit.jps?=CodigoProducto="+CodigoProductoEdit+"');\\n\""
                            + "</script>";
                }else{
                    HTMLResponse = "<script type='text/javascript'>"
                            + "alert('Error: No se puede Editar el producto')"
                            + "</script>";
                }                
                
            break;
            //-------------------------------------------------------------------------------------------------------------------------------------------//
            
            //-------------------------------------------------------------------------------------------------------------------------------------------//
            //control para eliminar un producto
            case "EliminarProducto":
                String CodigoProductoEliminar = request.getParameter("CodigoProductoEliminar");
                
                try{
                    int intCodigoProductoEliminar = Integer.parseInt(CodigoProductoEliminar);
                    
                    int ResultEliminar = Model.SQLDeleteProducto(intCodigoProductoEliminar);
                    
                    if(ResultEliminar == 1){
                        HTMLResponse = "<script type='text/javascript'>"
                            + "alert('Producto Eliminado con exito!');"
                            +"$('#contenido').load('../AdminDulceria.jps');\\n\""
                            + "</script>";
                    }else{
                        HTMLResponse = "<script type='text/javascript'>"
                            + "alert('Error: No se puede Eliminar el producto')"
                            + "</script>";
                    }                    
                    
                }catch(Exception e){
                    System.out.println(e.getMessage());
                        HTMLResponse = "<script type='text/javascript'>"
                            + "alert('Error: No se puede Eliminar el producto')"
                            + "</script>";
                }
                
             break;
            //-------------------------------------------------------------------------------------------------------------------------------------------//
            
            
            //-------------------------------------------------------------------------------------------------------------------------------------------//
            //Metodo por defecto en caso de un formulario no valido
            default:
                HTMLResponse = "<script type='text/javascript'>"
                + "console.log('%c Fallo en el manejo de formulario! la peticion es invaldia! Variable Form encontrada pero no valida', 'padding:15px;font-family:sans-serif;font-size:150%;background: #222; color: #bada55');"
                + "</script>";
                break;
            //-------------------------------------------------------------------------------------------------------------------------------------------//
        }
        
        //--->Imprimimos el codigo HTML en el navegador
       writer.println(HTMLResponse);
        
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
